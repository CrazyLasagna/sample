let a = 0;
let b = 0;
let c = 0;
let d = 0;
let fps = 0;

function setup () {
  createCanvas(1024, 1024);
  
  background(240);
  
  colorMode(RGB, 255, 255, 255, 1);
  
  let fps = 60;
  frameRate(fps);
}

function draw () {
  background(240);
  
  strokeWeight (1);
  stroke (0);
  
  let a = mouseX;
  let b = mouseY;
  let c = pmouseX - 64;
  let d = pmouseY;
  
  var distance = dist(c, d, a, b);
  var absDistance = abs(distance - 64);
  
  fill (235, 230, 87);
  
  arc (c, d, 64, 64, radians(30), radians(330));
  
  stroke (10, 10, 250);
  
  strokeWeight(5);
  
  fill (50, 50, 200);
  
  ellipse (a, b, 16, 16);
  
  print (absDistance);
}