function setup() {
  createCanvas(512, 512);
  background(240);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  fill (200,100,200,1);
  stroke(0);
  strokeWeight(1);
  //bezier(x1, y1, x2, y2, x3, y3, x4, y4)
  translate (-32,0);
  bezier(128,256,16,16,304,16,212,256);
  
  line (128,256,128,320);
  line (212,256,212,320);
  
  fill(255,179,102);
  beginShape();
    vertex(144,330);
    vertex(144,320);
    vertex(128,320);
    vertex(128,370);
    vertex(212,370);
    vertex(212,320);
    vertex(196,320);
    vertex(196,330);
    beginContour();
      vertex(136,345);
      vertex(204,345);
      vertex(204,355);
      vertex(136,355);
    endContour();
  endShape();

  
  fill(102,34,0);
  quad(136,345,204,345,204,355,136,355);

  
  fill(255,255,51);
  arc(464, 64, 80, 80, 0, radians(360));

  translate(40,48)
  fill(255,10,10);
  bezier(380,310,340,212,460,212,420,310);
  
  line(380,310,380,330);
  line(420,310,420,330);
  fill(125,125,255);
  quad(380,330,420,330,420,350,380,350);
  
  translate(-40,-48);
  fill(220,220,220,0.5);
  strokeWeight(0);
  bezier(0,400,150,350,400,370,512,400);
  quad(0,400,512,400,512,512,0,512);
  
}