function setup() {
  createCanvas(512, 512);
  background(248);
}

function draw() {
  
  //Weird Tower
  strokeWeight(3);
  stroke(0);
  line(117,194,117,140);
  
  strokeWeight(40);
  strokeCap(ROUND);
  stroke(100);
  line(117,512,117,192);
  

  strokeWeight(1);
  stroke(0);
  
  //Skyscrapers
  fill(140);
  rect(90,224,96,286)
  
  fill(90);
  rect(72,255,96,256);
  
  fill(220);
  rect(300,156,100,200);
  
  fill(180);
  rect(412,201,128,310)
  
  fill(180);
  rect(8,199,72,312);
  
  fill(175);
  rect(250,230,100,280)
  
  fill(128);
  rect(364,256,100,256)
  
  fill(100);
  rect(300,331,156,180);
  
  fill(220);
  rect(142,111,120,400)
  
  //Sun
  line(490,22,440,0);
  line(490,22,450,64);
  line(490,22,430,32);
  line(490,22,480,80);
  line(490,22,510,76);
  
  fill(236);
  ellipse(490,22,80,80)
  noFill();
  ellipse(490,22,70,70);
}